
<?php

if ($_REQUEST['Submit']=="Submit")
{
	
$name=$_REQUEST['name'];
$address=$_REQUEST['address'];
$city=$_REQUEST['city'];
$postal=$_REQUEST['postal'];
$country=$_REQUEST['country'];
$emailid=$_REQUEST['emailid'];
$phone=$_REQUEST['phone'];
$message1=$_REQUEST['message'];


$to = "automationtesthub@gmail.com";
$subject = "Contact Us From ATH Portal";

$from =$emailid;
$headers = "From:" . $from;
$message='<table width=573 border=1 cellpadding=0 cellspacing=0>
  <tr>
    <td colspan="2">Email Content</td>
  </tr>
  <tr>
    <td width="245">Name</td>
    <td width="328">'.$name.'</td>
  </tr>
  <tr>
    <td>address</td>
    <td>'.$address.'</td>
  </tr>
  <tr>
    <td>city</td>
    <td>'.$city.'</td>
  </tr>
  <tr>
    <td>postal</td>
    <td>'.$postal.'</td>
  </tr>
  <tr>
    <td>country</td>
    <td>'.$country.'</td>
  </tr>
   <tr>
    <td>emailid</td>
    <td>'.$emailid.'</td>
  </tr>
   <tr>
    <td>phone</td>
    <td>'.$phone.'</td>
  </tr>
   <tr>
    <td>message</td>
    <td>'.$message1.'</td>
  </tr>
</table>';
//echo $message;
mail($to,$subject,$message,$headers);

?>
<script type="text/javascript">
alert('Mail has been sent successfully');
window.location.href="contact_us.html";
</script>
<?php 
}
?>


